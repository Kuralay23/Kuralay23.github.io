<?php 

$data == $_POST;

if (isset($data['signup'])) {
    $error = array();
    if($data['name'] == ''){
      error[] = 'Введите ваш имя'
    }
    if ($data['email'] = '') {
      // code...
    }
    if(empty($error)){
      $user=R::dispense('users');
      $user->name = $data['name'];
      
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Sign-in</title>
  <link rel="stylesheet" type="text/css" href="auth.css">
</head>
<body>
  <nav>
        <ul>
        <a href="first.html">Main Menu</a>
        <a href="about.html">About Us</a>
        <a href="*">User Settings</a>
        <a href="*">Search</a>
        <a href="*">Upload Files</a>
        <a href="*">Chords</a>
        <a href="authorize.html">Sign-in</a>
    </ul>
      </nav>
  <div class="login-page">
    <div class="form">
      <form class="register-form" method="POST" id="regForm">
        <input type="text" name="name" placeholder="name"/>
        <input type="text" name="email" placeholder="email address"/>
        <input type="password" name="pass" placeholder="password"/>
        <button name="signup">create</button>
        <p class="message">Already registered? <a href="#">Sign In</a></p>
      </form>
      <form class="login-form" id="loginForm">
        <input type="text" name="email" placeholder="username"/>
        <input type="password" name="pass" placeholder="password"/>
        <button>login</button>
        <p class="message">Not registered? <a href="#">Create an account</a></p>
      </form>
    </div>
  </div>
</body>
</html>